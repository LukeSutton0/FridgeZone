import React from "react";

const ErrorContent = () =>{

    return(
        <div>
            <p>Page Unavailable, ensure you are logged in</p>
      </div>
    )
}

export default ErrorContent;